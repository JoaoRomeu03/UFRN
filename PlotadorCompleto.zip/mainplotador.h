#ifndef MAINPLOTADOR_H
#define MAINPLOTADOR_H

#include <QMainWindow>
#include "lehfuncao.h"
#include "grafico.h"
#include <QColor>
#include <vector>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainPlotador;
}
QT_END_NAMESPACE

class MainPlotador : public QMainWindow
{
    Q_OBJECT

public:
    MainPlotador(QWidget *parent = nullptr);
    ~MainPlotador();

private slots:
    void on_pushApagar_clicked();

    void on_spinExpX_valueChanged(int arg1);

    void on_spinExpY_valueChanged(int arg1);

    void on_spinMaxX_valueChanged(int arg1);

    void on_spinMaxY_valueChanged(int arg1);

    void on_spinMinX_valueChanged(int arg1);

    void on_spinMinY_valueChanged(int arg1);

    void on_actionFun_o_triggered();

    void on_actionApagar_triggered();

    void on_actionSair_triggered();

    void slotIncluirFuncao(QString funcao, QColor cor);

    void slotGraficoClicked(double X, double Y);


private:
    Ui::MainPlotador *ui;

    LehFuncao* lehFuncao;

    void exibirFuncoes();

    void desenharGrafico();

    Grafico *grafico;
};
#endif // MAINPLOTADOR_H
