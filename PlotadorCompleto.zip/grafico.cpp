#include "grafico.h"
#include <QSizePolicy>
#include <QFrame>
#include <QLineF>
#include <stdexcept>
#include <cmath>
#include <QResizeEvent>
#include <QPainter>
#include <QPen>
#include <QMouseEvent>

Grafico::Grafico(QWidget *parent) : QLabel(parent),
    largura(540), altura(540),
    minX(-10), maxX(10),
    minY(-10), maxY(10),
    nMarcX(10), nMarcY(10),
    img(QPixmap(largura, altura))
{
    setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    setMinimumSize(540, 540);
    setFrameShape(QFrame::Box);
    setFrameShadow(QFrame::Plain);
    setAlignment(Qt::AlignCenter);

    img.fill(Qt::white);
    setPixmap(img);
}

bool Grafico::empty() {
    return eval.empty();
}

size_t Grafico::size() {
    return eval.size();
}

const Evaluator& Grafico::getEval(int i) {
    return eval.at(i);
}

const QColor& Grafico::getCor(int i) {
    return cor.at(i);
}

void Grafico::pushFuncao(QString Funcao, QColor Cor) {
    Evaluator new_eval;
    new_eval.set(Funcao.toStdString());
    eval.push_back(new_eval);
    cor.push_back(Cor);
}

void Grafico::clearFuncoes() {
    eval.clear();
    cor.clear();
}

void Grafico::setLimites(int MinX, int MaxX, int ExpX, int MinY, int MaxY, int ExpY) {
    minX = MinX * pow(10.0, ExpX);
    maxX = MaxX * pow(10.0, ExpX);
    minY = MinY * pow(10.0, ExpY);
    maxY = MaxY * pow(10.0, ExpY);

    nMarcX = 1 + MaxX - MinX;
    nMarcY = 1 + MaxY - MinY;
}

double Grafico::convXtoJ(double X) const
{
    return static_cast<int>((largura - 1) * (X - minX) / (maxX - minX));
}

double Grafico::convYtoI(double Y) const
{
    return static_cast<int>((altura - 1) * (maxY - Y) / (maxY - minY));
}

double Grafico::convJtoX(double J) const
{
    return minX + (maxX - minX) * J / (largura - 1);
}

double Grafico::convItoY(double I) const
{
    return maxY - (maxY - minY) * I / (altura - 1);
}

void Grafico::desenharGrafico()
{
    QPen pen;
    QPainter painter;

    largura = this -> width();
    altura = this->height();

    QPixmap img(largura, altura);
    img.fill(Qt::white);

    painter.begin(&img);

    pen.setColor(Qt::black);
    pen.setWidth(3);
    painter.setPen(pen);

    double Izero = convYtoI(0.0);
    if(Izero >= 0.0 && Izero <= altura - 1.0)
    {
        painter.drawLine(QLineF(0.0, Izero, largura - 1.0, Izero));

        for (int i = 0; i < nMarcX; ++i)
        {
            double Jmarc = convXtoJ(minX + (maxX - minX) * i / (nMarcX - 1.0));
            painter.drawLine(QLineF(Jmarc, Izero - 3.0, Jmarc, Izero + 3.0));
        }
    }

    double Jzero = convXtoJ(0.0);
    if(Jzero >= 0.0 && Jzero <= largura - 1.0)
    {
        painter.drawLine(QLineF(Jzero, 0.0, Jzero, altura - 1.0));

        for(int i = 0; i < nMarcY; ++i)
        {
            double Imarc = convYtoI(minY + (maxY - minY) * i / (nMarcY - 1.0));
            painter.drawLine(QLineF(Jzero - 3.0, Imarc, Jzero + 3.0, Imarc));
        }
    }

    if(eval.empty())
    {
        painter.end();
        setPixmap(img);
        return;
    }

    pen.setWidth(1);

    double X, Y;
    double I, Iant;

    for(size_t k = 0; k < eval.size(); ++k)
    {
        pen.setColor(cor.at(k));
        painter.setPen(pen);

        Iant = -1.0;

        for(int J = 0; J < largura; ++J)
        {
            X = convJtoX(J);
            try {
                Y = eval.at(k)(X);
            } catch (...) {
                continue;
            }

            I = convYtoI(Y);

            if(I >= 0.0 && I <= altura - 1.0 && Iant >= 0.0 && Iant <= altura - 1.0)
            {
                painter.drawLine(QLineF(J - 1.0, Iant, J, I));
            }

            Iant = I;
        }
    }

    painter.end();
    this->setPixmap(img);
}

void Grafico::resizeEvent(QResizeEvent *event)
{

    if (event->oldSize() != event->size()) {
        desenharGrafico();
    }

    QLabel::resizeEvent(event);
}

void Grafico::mouseReleaseEvent(QMouseEvent *event)
{
    QPointF pos = event->position();

    double X = convJtoX(pos.x());
    double Y = convItoY(pos.y());

    emit signGraficoClicked(X, Y);

    QLabel::mouseReleaseEvent(event);
}
