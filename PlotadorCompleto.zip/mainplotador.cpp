#include "mainplotador.h"
#include "./ui_mainplotador.h"
#include "evaluator.h"
#include <QMessageBox>
#include <cmath>
#include <QLabel>
#include <QPixmap>
#include <QPen>
#include <QPainter>
#include <QLineF>

MainPlotador::MainPlotador(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainPlotador)
    , lehFuncao(new LehFuncao(this))

{
    ui->setupUi(this);

    grafico = new Grafico(this);

    connect(grafico, &Grafico::signGraficoClicked,
            this, &MainPlotador::slotGraficoClicked);

    connect(lehFuncao, SIGNAL(signIncluirFuncao(QString, QColor)),
        this, SLOT(slotIncluirFuncao(QString, QColor)));

    ui->tableFuncoes->setStyleSheet("QHeaderView::section {background-color:lightgray}");

    ui->tableFuncoes->horizontalHeader()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    ui->tableFuncoes->horizontalHeader()->setSectionResizeMode(1, QHeaderView::Stretch);

    ui->tableFuncoes->setHorizontalHeaderLabels(QStringList() << "COR" << "FUNCAO");

    grafico->setLimites(
        ui->spinMinX->value(),
        ui->spinMaxX->value(),
        ui->spinExpX->value(),
        ui->spinMinY->value(),
        ui->spinMaxY->value(),
        ui->spinExpY->value()
        );

    ui->horizontalLayout->insertWidget(0, grafico);
}

MainPlotador::~MainPlotador()
{
    delete ui;
}

void MainPlotador::on_pushApagar_clicked()
{
    grafico->clearFuncoes();
    exibirFuncoes();
}


void MainPlotador::on_spinExpX_valueChanged(int arg1)
{
    grafico->setLimites(
        ui->spinMinX->value(),
        ui->spinMaxX->value(),
        ui->spinExpX->value(),
        ui->spinMinY->value(),
        ui->spinMaxY->value(),
        ui->spinExpY->value()
        );
}


void MainPlotador::on_spinExpY_valueChanged(int arg1)
{
    grafico->setLimites(
        ui->spinMinX->value(),
        ui->spinMaxX->value(),
        ui->spinExpX->value(),
        ui->spinMinY->value(),
        ui->spinMaxY->value(),
        ui->spinExpY->value()
        );
}


void MainPlotador::on_spinMaxX_valueChanged(int arg1)
{
    grafico->setLimites(
        ui->spinMinX->value(),
        ui->spinMaxX->value(),
        ui->spinExpX->value(),
        ui->spinMinY->value(),
        ui->spinMaxY->value(),
        ui->spinExpY->value()
        );
}


void MainPlotador::on_spinMaxY_valueChanged(int arg1)
{
    grafico->setLimites(
        ui->spinMinX->value(),
        ui->spinMaxX->value(),
        ui->spinExpX->value(),
        ui->spinMinY->value(),
        ui->spinMaxY->value(),
        ui->spinExpY->value()
        );
}


void MainPlotador::on_spinMinX_valueChanged(int arg1)
{
    ui->spinMaxX -> setMinimum(1 + arg1);
    grafico->setLimites(
        ui->spinMinX->value(),
        ui->spinMaxX->value(),
        ui->spinExpX->value(),
        ui->spinMinY->value(),
        ui->spinMaxY->value(),
        ui->spinExpY->value()
        );
}


void MainPlotador::on_spinMinY_valueChanged(int arg1)
{

    ui->spinMaxY->setMinimum(1 + arg1);
    grafico->setLimites(
        ui->spinMinX->value(),
        ui->spinMaxX->value(),
        ui->spinExpX->value(),
        ui->spinMinY->value(),
        ui->spinMaxY->value(),
        ui->spinExpY->value()
        );
}

void MainPlotador::on_actionFun_o_triggered()
{
    lehFuncao->clear();
    lehFuncao->show();
}

void MainPlotador::on_actionApagar_triggered()
{
    on_pushApagar_clicked();
}

void MainPlotador::on_actionSair_triggered()
{
    QCoreApplication::quit();
}

void MainPlotador::exibirFuncoes()
{
    ui->tableFuncoes->clearContents();
    ui->tableFuncoes->setRowCount(grafico->size());

    QLabel *prov;
    QPixmap img(20, 20);

    for(size_t k = 0; k < grafico->size(); ++k)
    {
        img.fill(grafico->getCor(k));
        prov = new QLabel(this);
        prov->setAlignment(Qt::AlignCenter);
        prov->setPixmap(img);
        ui->tableFuncoes->setCellWidget(k, 0, prov);

        prov = new QLabel(this);
        prov->setAlignment(Qt::AlignVCenter | Qt::AlignLeft);
        prov->setWordWrap(true);
        prov->setText(QString::fromStdString(grafico->getEval(k).getText()));
        ui->tableFuncoes->setCellWidget(k, 1, prov);
    }
}

void MainPlotador::slotIncluirFuncao(QString funcao, QColor cor)
{
    try
    {
        grafico->pushFuncao(funcao, cor);
        exibirFuncoes();
    }

    catch (const std::invalid_argument &e)
    {
        QMessageBox::critical(this, "Funcao invalida", "Erro na funcao: " + QString::fromStdString(e.what()));
    }
}

void MainPlotador::desenharGrafico()
{
    grafico->desenharGrafico();
}

void MainPlotador::slotGraficoClicked(double X, double Y)
{
    QString msg = QString("X=%1  Y=%2").arg(X).arg(Y);
    statusBar()->showMessage(msg, 2000); // 2000 ms = 2 segundos
}



