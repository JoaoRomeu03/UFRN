#ifndef GRAFICO_H
#define GRAFICO_H

#include <QLabel>
#include <QColor>
#include <QPixmap>
#include <QPen>
#include <QPainter>
#include <vector>
#include <cmath>
#include "evaluator.h"

class Grafico : public QLabel
{
    Q_OBJECT

public:
    Grafico(QWidget *parent = nullptr);

    bool empty();
    size_t size();
    const Evaluator& getEval(int i);
    const QColor& getCor(int i);
    void pushFuncao(QString funcao, QColor cor);
    void clearFuncoes();
    void setLimites(int MinX, int MaxX, int ExpX, int MinY, int MaxY, int ExpY);
    void desenharGrafico();

signals:
    void signGraficoClicked(double X, double Y);

private:

    std::vector<Evaluator> eval;
    std::vector<QColor> cor;
    QPixmap img;
    int largura, altura;
    double minX, maxX, minY, maxY;
    int nMarcX, nMarcY;

    double convXtoJ(double X) const;
    double convYtoI(double Y) const;
    double convJtoX(double J) const;
    double convItoY(double I) const;

    void resizeEvent(QResizeEvent *event) override;

    void mouseReleaseEvent(QMouseEvent *event) override;


};

#endif // GRAFICO_H
